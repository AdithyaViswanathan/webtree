"""Web Scraping Tool"""

__author__ = """Abishek, Adithya"""
__version__ = '0.0.1'